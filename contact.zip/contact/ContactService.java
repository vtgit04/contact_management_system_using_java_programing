package com.contact;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ContactService {

    private Scanner scanner = new Scanner(System.in);
    private ArrayList<Contact> contacts = new ArrayList<>();

    public void addContact() {
        System.out.println("Enter Contact S.No.: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        System.out.println("Enter Contact Name: ");
        String name = scanner.nextLine();

        System.out.println("Enter Contact Phone: ");
        String phone = scanner.nextLine();

        System.out.println("Enter Contact Email: ");
        String email = scanner.nextLine();

        Contact contact = new Contact(id, name, phone, email);
        contacts.add(contact);
        System.out.println("Contact Added Successfully!");
    }

    public void listContacts() {
        if (contacts.isEmpty()) {
            System.out.println("No Contacts Found!");
        } else {
            for (Contact contact : contacts) {
                System.out.println(contact);
            }
        }
    }

    public void deleteContact() {
        System.out.println("Enter Contact S.No. to Delete: ");
        int id = scanner.nextInt();

        Contact contact = findContactById(id);
        if (contacts.remove(contact)) {
            System.out.println("Contact Deleted Successfully!");
        } else {
            System.out.println("Contact Not Found!");
        }
    }

    private Contact findContactById(int id) {
        for (Contact contact : contacts) {
            if (contact.getId() == id) {
                return contact;
            }
        }
        return null;
    }

    public void updateContact() {
        System.out.println("Enter Contact S.No. to Update: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        Contact contact = findContactById(id);
        if (contact != null) {
            System.out.println("Enter New Name (leave blank to keep old): ");
            String newName = scanner.nextLine();
            if (!newName.isEmpty()) {
                contact.setName(newName);
            }

            System.out.println("Enter New Phone (leave blank to keep old): ");
            String newPhone = scanner.nextLine();
            if (!newPhone.isEmpty()) {
                contact.setPhone(newPhone);
            }

            System.out.println("Enter New Email (leave blank to keep old): ");
            String newEmail = scanner.nextLine();
            if (!newEmail.isEmpty()) {
                contact.setEmail(newEmail);
            }

            System.out.println("Contact Updated Successfully!");
        } else {
            System.out.println("Contact Not Found!");
        }
    }

    public void searchContacts() {
        System.out.println("Search Contacts by:");
        System.out.println("1. Contact S.No.");
        System.out.println("2. Contact Name");
        System.out.println("3. Contact Phone Number");
        System.out.println("4. Contact Email");
        System.out.println("Enter choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        String searchTerm = "";
        switch (choice) {
            case 1:
                System.out.println("Enter Contact ID to search: ");
                searchTerm = String.valueOf(scanner.nextInt()); // Convert int to String for search
                break;
            case 2:
                System.out.println("Enter name to search: ");
                searchTerm = scanner.nextLine().toLowerCase(); // Lowercase for case-insensitive search
                break;
            case 3:
                System.out.println("Enter phone number to search: ");
                searchTerm = scanner.nextLine().toLowerCase(); // Lowercase for case-insensitive search
                break;
            case 4:
                System.out.println("Enter email to search: ");
                searchTerm = scanner.nextLine().toLowerCase(); // Lowercase for case-insensitive search
                break;
            default:
                System.out.println("Invalid Choice!");
                return;
        }

        List<Contact> foundContacts = new ArrayList<>();
        for (Contact contact : contacts) {
            if (choice == 1 && contact.getId() == Integer.parseInt(searchTerm)) {
                foundContacts.add(contact);
            } else if (choice == 2 && contact.getName().toLowerCase().contains(searchTerm)) {
                foundContacts.add(contact);
            } else if (choice == 3 && contact.getPhone().toLowerCase().contains(searchTerm)) {
                foundContacts.add(contact);
            } else if (choice == 4 && contact.getEmail().toLowerCase().contains(searchTerm)) {
                foundContacts.add(contact);
            }
        }

        if (foundContacts.isEmpty()) {
            System.out.println("No contacts found for the search term.");
        } else {
            System.out.println("Found " + foundContacts.size() + " contacts:");
            for (Contact contact : foundContacts) {
                System.out.println(contact);
            }
        }
    }
}